El ejercicio ha sido realizado por:

-Álvaro Vaya Arboledas
-David Menoyo Ros
-David Márquez Mínguez